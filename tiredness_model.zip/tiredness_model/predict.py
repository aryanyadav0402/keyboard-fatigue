"""Predict a typing-station session's tiredness (KSS) from its JSON file.
Usage: python predict.py session.json [--baseline-from PERSON]   (needs numpy, pandas only)
Predicted KSS = person's usual KSS + ridge(feature differences from their usual typing).
Person must already exist in person_baselines.json (they need earlier sessions)."""
import json, sys, os, numpy as np, pandas as pd
HERE=os.path.dirname(os.path.abspath(__file__))
MOD={'Shift','Control','Alt','Meta','CapsLock'}
def key_events(d):
    down={}; ev=[]
    for task,unit,typ,t,code,key,fl in d['keys']:
        if typ=='d':
            if fl&32: continue            # drop auto-repeat
            down[code]=(t,key)
        elif code in down:
            t0,k=down.pop(code); ev.append((k,t0/1000,(t-t0)/1000))
    e=pd.DataFrame(ev,columns=['k','pr','ht'])
    return e[~e.k.isin(MOD)&(e.ht>0)&(e.ht<2)].sort_values('pr').reset_index(drop=True)
def features(e):
    iki=np.diff(e.pr.values); L=e.pr.max()-e.pr.min()+1e-9
    return dict(log_iki_med=np.log(np.median(iki)),log_iki_sd=np.log(iki.std()+1e-3),iki_cv=iki.std()/iki.mean(),
        cps=len(e)/L,pauses_pm=(iki>1).sum()/L*60,pause_frac=iki[iki>1].sum()/L,
        log_dwell=np.log(e.ht.median()),bs_rate=(e.k=='Backspace').mean())
def predict(path,use_session_order=False):
    W=json.load(open(f'{HERE}/model_weights.json')); B=json.load(open(f'{HERE}/person_baselines.json'))
    d=json.load(open(path)); pid=d['participant_id']
    if pid not in B: raise SystemExit(f'No baseline for {pid}: needs earlier sessions (known people: {list(B)})')
    f=features(key_events(d)); b=B[pid]
    z={k:f[k]-b['usual_features'][k] for k in W['feature_order']}; z['ses']=d['local_session_number']-b['usual_session_number']
    m=W['models']['typing_plus_session_order' if use_session_order else 'typing_only']
    x=(np.array([z[c] for c in m['columns']])-np.array(m['scaler_mean']))/np.array(m['scaler_scale'])
    shift=float(x@np.array(m['coef'])+m['intercept'])
    return dict(person=pid,session=d['local_session_number'],usual_kss=b['usual_kss'],predicted_shift=shift,predicted_kss=b['usual_kss']+shift)
if __name__=='__main__':
    for p in [a for a in sys.argv[1:] if not a.startswith('--')]:
        for o in (False,True):
            r=predict(p,o); print(f"{r['person']} #{r['session']}  usual {r['usual_kss']:.1f}  ->  predicted KSS {r['predicted_kss']:.1f}  ({'typing + session order' if o else 'typing only'})")
