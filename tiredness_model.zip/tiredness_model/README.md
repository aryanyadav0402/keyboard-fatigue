# Per-person tiredness (KSS) model
Ridge regression on how a session's typing differs from that person's own usual sessions.
Trained on 36 usable sessions (40 real typing-station sessions, 8 people; 4 one-session people have no baseline).

Files
- model_weights.json     scaler mean/scale, ridge coefficients and intercept for both variants (portable, no sklearn needed)
- model.joblib           the same two fitted sklearn pipelines (StandardScaler + Ridge alpha=10): typing_only, typing_plus_session_order
- person_baselines.json  each person's usual features, usual KSS and usual session number (the personal baseline)
- predict.py             standalone inference: python predict.py session.json
Notes: predicted KSS = usual KSS + predicted shift. Only people in person_baselines.json can be scored. The session-order variant is partly a time-of-evening proxy; trust typing_only more.
