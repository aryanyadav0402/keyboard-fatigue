#!/usr/bin/env python3
"""Turn raw Typing Station sessions into analysis-ready CSV tables (standard library only).

    python export.py                                   # reads ./data/sessions, writes ./out
    python export.py --in data/sessions --in ~/Downloads --out out

Inputs can be: collector folders, folders of downloaded tsession_*.json files, or
typing_station_backup_*.json files. They are searched recursively. Duplicates (same
session_id) are merged: a completed/final copy beats a partial one.

Outputs (in --out):
  sessions.csv          one row per session: metadata, self-report, derived labels, QC flags, summaries
  pvt_trials.csv        every reaction-test response (including practice, false starts, timeouts)
  keystrokes.csv        every raw key down/up event in the typing tasks (+ decoded modifier flags)
  keystroke_timings.csv one row per key press with hold / flight times (analysis-ready)
  typing_units.csv      one row per typed sentence / free-text block with speed, accuracy, errors
  input_events.csv      text-box input events (insertText, deleteContentBackward, ...)
  ui_events.csv         screens, window blur/focus, tab switches, blocked pastes
  qc_report.txt         what is complete, what is suspicious
  DATA_DICTIONARY.md    column meanings (copied next to the tables)
"""
import argparse
import csv
import datetime as dt
import json
import math
import shutil
import statistics as st
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
MODS = {"Shift", "Control", "Alt", "Meta", "CapsLock", "AltGraph", "OS"}
LAPSE_MS = 355          # brief PVT lapse threshold
LAPSE_CLASSIC_MS = 500  # classic PVT lapse threshold
FALSE_START_MS = 100


# ----------------------------------------------------------------------------- loading
def iter_json_files(dirs):
    for d in dirs:
        p = Path(d).expanduser()
        if p.is_file() and p.suffix == ".json":
            yield p
        elif p.is_dir():
            for f in sorted(p.rglob("*.json")):
                yield f


def load_sessions(dirs):
    best = {}      # session_id -> (rank, obj, source)
    n_files = n_bad = 0
    for f in iter_json_files(dirs):
        try:
            obj = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            n_bad += 1
            continue
        items = []
        if isinstance(obj, dict) and obj.get("schema") == "typing-station":
            items = [obj]
        elif isinstance(obj, dict) and obj.get("schema") == "typing-station-backup":
            items = [s for s in obj.get("sessions", []) if isinstance(s, dict) and s.get("schema") == "typing-station"]
        else:
            continue
        n_files += 1
        in_partial = "partial" in f.parts
        for s in items:
            sid = s.get("session_id")
            if not sid:
                continue
            final = s.get("status") == "final"
            n_events = len(s.get("keys", [])) + len(s.get("pvt", []))
            rank = (1 if final else 0, 1 if s.get("completed") else 0, n_events, 0 if in_partial else 1)
            if sid not in best or rank > best[sid][0]:
                best[sid] = (rank, s, str(f))
    return [(b[1], b[2]) for b in best.values()], n_files, n_bad


# ----------------------------------------------------------------------------- helpers
def r3(x):
    return None if x is None or (isinstance(x, float) and math.isnan(x)) else round(x, 3)


def med(v):
    v = [x for x in v if x is not None]
    return st.median(v) if v else None


def iqr(v):
    v = sorted(x for x in v if x is not None)
    if len(v) < 4:
        return None
    q = st.quantiles(v, n=4, method="inclusive")
    return q[2] - q[0]


def mean(v):
    v = [x for x in v if x is not None]
    return sum(v) / len(v) if v else None


def lev(a, b):
    if a == b:
        return 0
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def decode(flags):
    return (bool(flags & 1), bool(flags & 2), bool(flags & 4), bool(flags & 8),
            bool(flags & 16), bool(flags & 32), bool(flags & 64), bool(flags & 128))


def epoch(s, t):
    if t is None:
        return None
    return s["clock"]["time_origin_epoch_ms"] + t


def iso_local(ms, off_min):
    if ms is None:
        return None
    tz = dt.timezone(dt.timedelta(minutes=off_min or 0))
    return dt.datetime.fromtimestamp(ms / 1000, tz).isoformat(timespec="seconds")


def rows_of(s, name):
    fields = s.get(name + "_fields") or s.get({"keys": "key_fields", "inputs": "input_fields", "pvt": "pvt_fields", "ui": "ui_fields"}[name])
    return [dict(zip(fields, r)) for r in s.get(name, [])]


def hours_awake(s):
    sr = s.get("self_report") or {}
    wt = sr.get("wake_time")
    start = s["clock"]["start_epoch_ms"]
    off = s["clock"].get("tz_offset_min") or 0
    if not wt:
        return None
    try:
        hh, mm = [int(x) for x in wt.split(":")[:2]]
    except Exception:
        return None
    tz = dt.timezone(dt.timedelta(minutes=off))
    t0 = dt.datetime.fromtimestamp(start / 1000, tz)
    wake = t0.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if wake > t0:
        wake -= dt.timedelta(days=1)
    return (t0 - wake).total_seconds() / 3600


# ----------------------------------------------------------------------------- key press pairing
def pair_presses(key_rows, task_names):
    """Group raw events into presses. Auto-repeat downs are counted but not treated as new presses."""
    groups = defaultdict(list)
    for r in key_rows:
        groups[(r["task"], r["unit"])].append(r)
    presses = []
    stats = defaultdict(lambda: {"repeats": 0, "unmatched_up": 0, "unmatched_down": 0})
    for (task, unit), evs in groups.items():
        evs.sort(key=lambda r: r["t"])
        open_down = {}
        seq = []
        for r in evs:
            sh, ct, al, me, caps, rep, comp, untr = decode(r["flags"])
            if r["type"] == "d":
                if rep:
                    stats[(task, unit)]["repeats"] += 1
                    if r["code"] == "Backspace" or r["code"] == "Delete":
                        # keep a count of held-key repeats separately for backspace analysis
                        pass
                    continue
                p = {"task": task, "unit": unit, "code": r["code"], "key": r["key"], "down_t": r["t"], "up_t": None,
                     "shift": sh, "ctrl": ct, "alt": al, "meta": me, "caps": caps, "composing": comp, "untrusted": untr}
                open_down[r["code"]] = p
                seq.append(p)
            else:
                p = open_down.pop(r["code"], None)
                if p is None:
                    stats[(task, unit)]["unmatched_up"] += 1
                else:
                    p["up_t"] = r["t"]
        stats[(task, unit)]["unmatched_down"] = sum(1 for p in seq if p["up_t"] is None)
        # flight times over non-modifier keys only
        prev = None
        for i, p in enumerate(seq):
            p["order"] = i
            p["hold_ms"] = (p["up_t"] - p["down_t"]) if p["up_t"] is not None else None
            p["is_modifier"] = p["code"].replace("Left", "").replace("Right", "") in MODS or p["key"] in MODS
            p["is_backspace"] = p["key"] in ("Backspace", "Delete")
            p["is_enter"] = p["key"] == "Enter"
            p["is_char"] = (not p["is_modifier"]) and (len(p["key"]) == 1)
            if p["is_modifier"]:
                p["dd_ms"] = p["ud_ms"] = p["prev_code"] = None
                continue
            if prev is None:
                p["dd_ms"] = p["ud_ms"] = None
                p["prev_code"] = None
            else:
                p["dd_ms"] = p["down_t"] - prev["down_t"]
                p["ud_ms"] = (p["down_t"] - prev["up_t"]) if prev["up_t"] is not None else None
                p["prev_code"] = prev["code"]
            prev = p
        presses.extend(seq)
    return presses, stats


# ----------------------------------------------------------------------------- PVT metrics
def pvt_metrics(trials):
    main = [r for r in trials if r["phase"] == "main"]
    resp = [r for r in main if r["outcome"] in ("valid", "lapse")]
    rts = [r["rt_ms"] for r in resp]
    fs = sum(1 for r in main if r["outcome"] == "false_start")
    to = sum(1 for r in main if r["outcome"] == "timeout")
    lapses = sum(1 for r in resp if r["rt_ms"] >= LAPSE_MS)
    lapses500 = sum(1 for r in resp if r["rt_ms"] >= LAPSE_CLASSIC_MS)
    n_stim = len(resp) + to
    out = {"pvt_n_main_rows": len(main), "pvt_n_responses": len(rts), "pvt_n_false_starts": fs, "pvt_n_timeouts": to,
           "pvt_lapses_355": lapses, "pvt_lapses_500": lapses500}
    if rts:
        srt = sorted(rts)
        k = max(1, math.ceil(0.1 * len(srt)))
        out.update({
            "pvt_mean_rt_ms": r3(mean(rts)), "pvt_median_rt_ms": r3(med(rts)),
            "pvt_mean_inv_rt_per_s": r3(mean([1000.0 / x for x in rts])),
            "pvt_slowest10_inv_rt_per_s": r3(mean([1000.0 / x for x in srt[-k:]])),
            "pvt_fastest10_rt_ms": r3(mean(srt[:k])),
            "pvt_rt_sd_ms": r3(st.pstdev(rts)) if len(rts) > 1 else None,
        })
    denom = n_stim + fs
    out["pvt_score"] = r3(1 - (lapses + fs) / denom) if denom else None
    return out


# ----------------------------------------------------------------------------- build tables
def main():
    ap = argparse.ArgumentParser(description="Export Typing Station data to CSV")
    ap.add_argument("--in", dest="inputs", action="append", default=[], help="folder or file (repeatable). Default: ./data/sessions")
    ap.add_argument("--out", default="out")
    ap.add_argument("--include-test", action="store_true", help="also export sessions recorded with ?test=1")
    a = ap.parse_args()
    inputs = a.inputs or [str(HERE / "data" / "sessions")]
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    sessions, n_files, n_bad = load_sessions(inputs)
    skipped_test = [s for s, _ in sessions if s.get("test_mode")]
    if not a.include_test:
        sessions = [(s, f) for s, f in sessions if not s.get("test_mode")]
    sessions.sort(key=lambda sf: sf[0]["clock"]["start_epoch_ms"])
    if not sessions:
        print("No sessions found in:", ", ".join(inputs))
        if skipped_test:
            print(f"({len(skipped_test)} test-mode session(s) skipped; use --include-test to include them)")
        sys.exit(1)

    # per-participant order + forward-filled profile
    by_pid = defaultdict(list)
    for s, f in sessions:
        by_pid[s["participant_id"]].append(s)
    profile = {}
    sess_index, first_start = {}, {}
    for pid, lst in by_pid.items():
        lst.sort(key=lambda s: s["clock"]["start_epoch_ms"])
        prof = {}
        for i, s in enumerate(lst, 1):
            sess_index[s["session_id"]] = i
            if s.get("profile"):
                prof.update(s["profile"])
        profile[pid] = prof
        first_start[pid] = lst[0]["clock"]["start_epoch_ms"]

    W = {}
    def writer(name, cols):
        f = open(out / name, "w", newline="", encoding="utf-8")
        w = csv.writer(f)
        w.writerow(cols)
        W[name] = f
        return w

    sess_cols = ["session_id", "participant_id", "participant_name", "cohort", "session_index", "local_session_number", "collector", "station_id",
                 "start_utc", "start_local", "tz_offset_min", "local_hour", "hours_since_first_session", "duration_min",
                 "completed", "recovered", "aborted", "app_version", "consent_version", "consent_reconfirmed",
                 "os_platform", "browser_ua", "screen_w", "screen_h", "dpr", "refresh_hz_est", "keyboard_type", "posture",
                 "kss", "mental_fatigue", "motivation", "wake_time", "hours_awake", "sleep_last_night_h", "nap_since_last_min",
                 "caffeine_last3h", "caffeine_min_ago", "interrupted", "notes",
                 "age_band", "touch_typing", "typing_speed_band", "handedness", "native_english", "laptop_model",
                 "pvt_n_main_rows", "pvt_n_responses", "pvt_n_false_starts", "pvt_n_timeouts", "pvt_lapses_355", "pvt_lapses_500",
                 "pvt_mean_rt_ms", "pvt_median_rt_ms", "pvt_mean_inv_rt_per_s", "pvt_slowest10_inv_rt_per_s",
                 "pvt_fastest10_rt_ms", "pvt_rt_sd_ms", "pvt_score"]
    sess_cols += ["transform_question_ids", "transform_question_types", "free_prompt_id"]
    for pre in ("transform", "free"):
        sess_cols += [f"{pre}_n_presses", f"{pre}_wpm", f"{pre}_accuracy", f"{pre}_exact_match_rate", f"{pre}_think_time_s",
                      f"{pre}_backspace_per_100_keys", f"{pre}_hold_med_ms", f"{pre}_hold_iqr_ms", f"{pre}_dd_med_ms", f"{pre}_dd_iqr_ms",
                      f"{pre}_pauses_1s_per_100_keys", f"{pre}_pauses_2s_per_100_keys"]
    sess_cols += ["n_key_events", "n_blur_events", "n_hidden_events", "n_paste_blocked", "n_untrusted_keys", "qc_flags", "source_file"]
    w_sess = writer("sessions.csv", sess_cols)
    w_pvt = writer("pvt_trials.csv", ["session_id", "participant_id", "phase", "trial", "isi_ms", "onset_t_ms", "onset_epoch_ms", "resp_t_ms",
                                      "rt_ms", "outcome", "code", "session_index", "is_lapse_355"])
    w_key = writer("keystrokes.csv", ["session_id", "participant_id", "task", "task_name", "unit", "type", "t_ms", "epoch_ms", "code", "key",
                                      "shift", "ctrl", "alt", "meta", "caps_on", "repeat", "composing", "untrusted"])
    w_tim = writer("keystroke_timings.csv", ["session_id", "participant_id", "task", "task_name", "unit", "order", "code", "key", "prev_code",
                                             "down_t_ms", "up_t_ms", "hold_ms", "dd_ms", "ud_ms", "is_char", "is_backspace", "is_enter",
                                             "is_modifier", "shift", "ctrl", "alt", "meta", "caps_on", "composing", "untrusted"])
    w_unit = writer("typing_units.csv", ["session_id", "participant_id", "task_name", "unit", "kind", "question_id", "question_type", "instruction",
                                         "source_text", "prompt_id", "prompt", "expected", "typed", "len_expected", "len_typed", "edit_distance",
                                         "accuracy", "exact_match", "t_shown_ms", "t_first_key_ms", "t_end_ms", "think_time_s",
                                         "duration_s", "wpm", "n_presses", "n_backspace", "n_repeat_events", "skipped"])
    w_inp = writer("input_events.csv", ["session_id", "participant_id", "task", "unit", "t_ms", "epoch_ms", "input_type", "text_len", "caret"])
    w_ui = writer("ui_events.csv", ["session_id", "participant_id", "t_ms", "epoch_ms", "event", "detail"])

    qc = []                       # (session_id, pid, [flags])
    per_pid_rows = defaultdict(list)

    for s, src in sessions:
        sid, pid = s["session_id"], s["participant_id"]
        clock = s["clock"]
        off = clock.get("tz_offset_min") or 0
        tz = dt.timezone(dt.timedelta(minutes=off))
        start_dt = dt.datetime.fromtimestamp(clock["start_epoch_ms"] / 1000, tz)
        task_name = {t["idx"]: t["name"] for t in s.get("tasks", [])}
        keys = rows_of(s, "keys")
        inputs = rows_of(s, "inputs")
        trials = rows_of(s, "pvt")
        uis = rows_of(s, "ui")
        units = s.get("units", [])
        sr = s.get("self_report") or {}
        post = s.get("post") or {}
        prof = profile.get(pid, {})
        dev = s.get("device", {})

        # ---- raw tables
        for r in keys:
            sh, ct, al, me, caps, rep, comp, untr = decode(r["flags"])
            w_key.writerow([sid, pid, r["task"], task_name.get(r["task"]), r["unit"], r["type"], r["t"], r3(epoch(s, r["t"])), r["code"], r["key"],
                            int(sh), int(ct), int(al), int(me), int(caps), int(rep), int(comp), int(untr)])
        for r in inputs:
            w_inp.writerow([sid, pid, r["task"], r["unit"], r["t"], r3(epoch(s, r["t"])), r["input_type"], r["len"], r["caret"]])
        for r in uis:
            w_ui.writerow([sid, pid, r["t"], r3(epoch(s, r["t"])), r["event"], r["detail"]])
        for r in trials:
            w_pvt.writerow([sid, pid, r["phase"], r["trial"], r["isi_ms"], r["onset_t"], r3(epoch(s, r["onset_t"])), r["resp_t"], r["rt_ms"],
                            r["outcome"], r["code"], sess_index[sid], int(r["rt_ms"] >= LAPSE_MS) if r["rt_ms"] is not None else None])

        # ---- keystroke timings
        presses, pstats = pair_presses(keys, task_name)
        for p in presses:
            w_tim.writerow([sid, pid, p["task"], task_name.get(p["task"]), p["unit"], p["order"], p["code"], p["key"], p["prev_code"],
                            p["down_t"], p["up_t"], r3(p["hold_ms"]), r3(p["dd_ms"]), r3(p["ud_ms"]), int(p["is_char"]), int(p["is_backspace"]),
                            int(p["is_enter"]), int(p["is_modifier"]), int(p["shift"]), int(p["ctrl"]), int(p["alt"]), int(p["meta"]),
                            int(p["caps"]), int(p["composing"]), int(p["untrusted"])])

        # ---- typing units
        unit_rows = []
        for u in units:
            ps = [p for p in presses if p["task"] == u["task"] and p["unit"] == u["unit"] and not p["is_modifier"]]
            typed = u.get("typed") or ""
            target = u.get("expected")
            ed = lev(target, typed) if target else None
            acc = (1 - ed / max(1, len(target))) if target else None
            exact = int(typed == target) if target else None
            t1, t2 = u.get("t_first_key"), u.get("t_end")
            think = ((t1 - u["t_shown"]) / 1000.0) if (t1 is not None and u.get("t_shown") is not None and t1 >= u["t_shown"]) else None
            dur = ((t2 - t1) / 1000.0) if (t1 is not None and t2 is not None and t2 > t1) else None
            wpm = (len(typed) / 5.0) / (dur / 60.0) if dur else None
            nb = sum(1 for p in ps if p["is_backspace"])
            nrep = pstats[(u["task"], u["unit"])]["repeats"]
            row = [sid, pid, task_name.get(u["task"]), u["unit"], u["kind"], u.get("question_id"), u.get("question_type"), u.get("instruction"),
                   u.get("source"), u.get("prompt_id"), u.get("prompt"), target, typed, len(target) if target else None,
                   len(typed), ed, r3(acc), exact, u.get("t_shown"), t1, t2, r3(think), r3(dur), r3(wpm), len(ps), nb, nrep,
                   int(bool(u.get("skipped")))]
            w_unit.writerow(row)
            unit_rows.append((u, ps, dur, wpm, acc, nb, think, exact))

        def summarise(kind):
            sel = [x for x in unit_rows if x[0]["kind"] == kind and not x[0].get("skipped")]
            if not sel:
                return {}
            ps = [p for x in sel for p in x[1]]
            n = len(ps)
            letters = [p for p in ps if p["is_char"] and p["key"].isalpha()]
            holds = [p["hold_ms"] for p in letters if p["hold_ms"] is not None and 0 < p["hold_ms"] < 1000]
            dds = [p["dd_ms"] for p in ps if p["dd_ms"] is not None and p["dd_ms"] > 0]
            dd_short = [x for x in dds if x < 2000]
            tot_dur = sum(x[2] for x in sel if x[2])
            chars = sum(len(x[0].get("typed") or "") for x in sel)
            wpm = (chars / 5.0) / (tot_dur / 60.0) if tot_dur else None
            accs = [x[4] for x in sel if x[4] is not None]
            thinks = [x[6] for x in sel if x[6] is not None]
            exacts = [x[7] for x in sel if x[7] is not None]
            return {
                "n_presses": n, "wpm": r3(wpm), "accuracy": r3(mean(accs)) if accs else None,
                "exact_match_rate": r3(mean(exacts)) if exacts else None, "think_time_s": r3(mean(thinks)),
                "backspace_per_100_keys": r3(100.0 * sum(x[5] for x in sel) / n) if n else None,
                "hold_med_ms": r3(med(holds)), "hold_iqr_ms": r3(iqr(holds)),
                "dd_med_ms": r3(med(dd_short)), "dd_iqr_ms": r3(iqr(dd_short)),
                "pauses_1s_per_100_keys": r3(100.0 * sum(1 for x in dds if x >= 1000) / n) if n else None,
                "pauses_2s_per_100_keys": r3(100.0 * sum(1 for x in dds if x >= 2000) / n) if n else None,
            }
        tr_s, free_s = summarise("transform"), summarise("free")

        # ---- QC flags
        flags = []
        if s.get("recovered"):
            flags.append("recovered_after_crash")
        if s.get("aborted"):
            flags.append("aborted")
        if not s.get("completed"):
            flags.append("incomplete")
        if not s.get("self_report"):
            flags.append("no_self_report")
        if s.get("error"):
            flags.append("js_error")
        main_trials = [r for r in trials if r["phase"] == "main"]
        pm = pvt_metrics(trials)
        pvt_dur = (s.get("config", {}).get("durations_s", {}) or {}).get("pvt_main_s", 180)
        if s.get("tasks") and any(t["name"] == "pvt_main" for t in s["tasks"]):
            if pm["pvt_n_responses"] < 0.4 * pvt_dur / 2.5:
                flags.append("pvt_few_responses")
            if pm["pvt_n_responses"] and pm["pvt_n_false_starts"] > 0.25 * (pm["pvt_n_responses"] + pm["pvt_n_false_starts"]):
                flags.append("pvt_many_false_starts")
            if pm["pvt_n_timeouts"] >= 3:
                flags.append("pvt_timeouts")
        else:
            flags.append("no_pvt")
        exp_len = sum(len(x[0].get("expected") or "") for x in unit_rows if x[0]["kind"] == "transform")
        if not tr_s:
            flags.append("no_transform")
        elif tr_s["n_presses"] < 0.6 * exp_len:
            flags.append("transform_few_keys")
        elif tr_s["accuracy"] is not None and tr_s["accuracy"] < 0.7:
            flags.append("transform_low_accuracy")
        if (s.get("config") or {}).get("free_task", True):  # sessions from app v1.1+ have no free-text task
            if not free_s:
                flags.append("no_free_text")
            elif free_s["n_presses"] < 80:
                flags.append("free_few_keys")
        n_blur = sum(1 for r in uis if r["event"] in ("window_blur", "textarea_blur"))
        n_hidden = sum(1 for r in uis if r["event"] == "visibility" and r["detail"] == "hidden")
        n_paste = sum(1 for r in uis if r["event"] in ("paste_blocked", "drop_blocked"))
        n_untr = sum(1 for r in keys if r["flags"] & 128)
        if n_hidden:
            flags.append("tab_hidden")
        if n_blur >= 3:
            flags.append("many_blur_events")
        if n_paste:
            flags.append("paste_attempt")
        if n_untr:
            flags.append("untrusted_key_events")
        if post.get("interrupted") in ("lot",):
            flags.append("reported_interrupted_a_lot")
        hz = dev.get("refresh_hz_est")
        if hz and hz < 45:
            flags.append("low_refresh_rate")
        end = s.get("end") or {}
        dur_min = None
        if end.get("end_epoch_ms"):
            dur_min = (end["end_epoch_ms"] - clock["start_epoch_ms"]) / 60000.0
            if end.get("end_perf_ms") is not None and clock.get("start_perf_ms") is not None:
                if abs((end["end_epoch_ms"] - clock["start_epoch_ms"]) - (end["end_perf_ms"] - clock["start_perf_ms"])) > 3000:
                    flags.append("system_clock_jump")
        if s.get("test_mode"):
            flags.append("TEST_MODE")
        un = sum(pstats[k]["unmatched_down"] for k in pstats)
        if keys and un > 0.05 * max(1, len(presses)):
            flags.append("many_unmatched_keys")
        qc.append((sid, pid, flags))

        ua = dev.get("user_agent") or ""
        row = {
            "session_id": sid, "participant_id": pid, "participant_name": s.get("participant_name"), "cohort": s.get("cohort"), "session_index": sess_index[sid],
            "local_session_number": s.get("local_session_number"), "collector": s.get("collector"), "station_id": s.get("station_id"),
            "start_utc": dt.datetime.fromtimestamp(clock["start_epoch_ms"] / 1000, dt.timezone.utc).isoformat(timespec="seconds"),
            "start_local": start_dt.isoformat(timespec="seconds"), "tz_offset_min": off, "local_hour": r3(start_dt.hour + start_dt.minute / 60.0),
            "hours_since_first_session": r3((clock["start_epoch_ms"] - first_start[pid]) / 3.6e6), "duration_min": r3(dur_min),
            "completed": int(bool(s.get("completed"))), "recovered": int(bool(s.get("recovered"))), "aborted": int(bool(s.get("aborted"))),
            "app_version": s.get("app_version"), "consent_version": (s.get("consent") or {}).get("version"),
            "consent_reconfirmed": (s.get("consent") or {}).get("reconfirmed"),
            "os_platform": dev.get("ua_platform") or dev.get("platform"), "browser_ua": ua,
            "screen_w": (dev.get("screen") or {}).get("w"), "screen_h": (dev.get("screen") or {}).get("h"), "dpr": (dev.get("screen") or {}).get("dpr"),
            "refresh_hz_est": hz, "keyboard_type": sr.get("keyboard_type"), "posture": sr.get("posture"),
            "kss": sr.get("kss"), "mental_fatigue": sr.get("mental_fatigue"), "motivation": sr.get("motivation"),
            "wake_time": sr.get("wake_time"), "hours_awake": r3(hours_awake(s)), "sleep_last_night_h": sr.get("sleep_last_night_h"),
            "nap_since_last_min": sr.get("nap_since_last_min"), "caffeine_last3h": sr.get("caffeine_last3h"),
            "caffeine_min_ago": sr.get("caffeine_min_ago"), "interrupted": post.get("interrupted"), "notes": post.get("notes"),
            "age_band": prof.get("age_band"), "touch_typing": prof.get("touch_typing"), "typing_speed_band": prof.get("typing_speed_band"),
            "handedness": prof.get("handedness"), "native_english": prof.get("native_english"), "laptop_model": prof.get("laptop_model"),
            "n_key_events": len(keys), "n_blur_events": n_blur, "n_hidden_events": n_hidden, "n_paste_blocked": n_paste,
            "n_untrusted_keys": n_untr, "qc_flags": ";".join(flags), "source_file": src,
        }
        row.update(pm)
        tq = [u for u in units if u.get("kind") == "transform"]
        row["transform_question_ids"] = ";".join(str(u.get("question_id")) for u in tq) or None
        row["transform_question_types"] = ";".join(str(u.get("question_type")) for u in tq) or None
        row["free_prompt_id"] = next((u.get("prompt_id") for u in units if u.get("kind") == "free"), None)
        for pre, d in (("transform", tr_s), ("free", free_s)):
            for k, v in d.items():
                row[f"{pre}_{k}"] = v
        w_sess.writerow([row.get(c) for c in sess_cols])
        per_pid_rows[pid].append(row)

    for f in W.values():
        f.close()
    shutil.copy(HERE / "DATA_DICTIONARY.md", out / "DATA_DICTIONARY.md") if (HERE / "DATA_DICTIONARY.md").exists() else None

    # ---- QC report
    lines = []
    lines.append(f"Typing Station export — {dt.datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"Read {n_files} file(s) ({n_bad} unreadable). {len(sessions)} unique session(s) exported"
                 + (f"; {len(skipped_test)} test-mode session(s) {'included' if a.include_test else 'skipped'}." if skipped_test else "."))
    comp = sum(1 for _, _, f in qc if "incomplete" not in f)
    lines.append(f"Complete: {comp}/{len(qc)}   Flagged (any QC flag except none): {sum(1 for _, _, f in qc if f)}")
    lines.append("")
    lines.append(f"{'participant':<12}{'cohort':<10}{'sessions':>8}{'complete':>9}  first -> last (local)")
    for pid, rows in sorted(per_pid_rows.items()):
        c = sum(r["completed"] for r in rows)
        lines.append(f"{pid:<12}{str(rows[0]['cohort']):<10}{len(rows):>8}{c:>9}  {rows[0]['start_local']} -> {rows[-1]['start_local']}")
    lines.append("")
    lines.append("Sessions with QC flags:")
    any_flag = False
    for sid, pid, f in qc:
        if f:
            any_flag = True
            lines.append(f"  {pid:<10} {sid[:8]}  {', '.join(f)}")
    if not any_flag:
        lines.append("  (none)")
    lines.append("")
    lines.append("Flag meanings: see DATA_DICTIONARY.md (section QC flags).")
    (out / "qc_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    print(f"\nWrote tables to {out.resolve()}")


if __name__ == "__main__":
    main()
