#!/usr/bin/env python3
"""Compute model features from raw Typing Station session JSON files (one row per session x typing task).

    python3 features.py                                  # reads data/sessions  -> out/features.csv
    python3 features.py --in some.json --in folder/ --out out --include-test

Uses the same press-pairing as export.py, so numbers agree with sessions.csv.
Everything is computed from the raw event list  keys = [task, unit, 'd'/'u', t_ms, code, key, flags].
Features are per typing task. Use --kind transform (default) or free (old v1.0 sessions only).
"""
import argparse
import csv
import statistics as st
from pathlib import Path

import export as E

HERE = Path(__file__).resolve().parent
LONG_GAP_MS = 500


def sd(v):
    return st.pstdev(v) if len(v) > 1 else None


def var(v):
    return st.pvariance(v) if len(v) > 1 else None


def features_for(s, kind):
    keys = E.rows_of(s, "keys")
    uis = E.rows_of(s, "ui")
    presses, _ = E.pair_presses(keys, {t["idx"]: t["name"] for t in s.get("tasks", [])})
    out = []
    for u in [u for u in s.get("units", []) if u["kind"] == kind and not u.get("skipped")]:
        ps = sorted([p for p in presses if p["task"] == u["task"] and p["unit"] == u["unit"] and not p["is_modifier"]], key=lambda p: p["down_t"])
        if not ps:
            continue
        typed, target = u.get("typed") or "", u.get("expected")
        t_show, t1, t2 = u.get("t_shown"), u.get("t_first_key"), u.get("t_end")
        dur = (t2 - t1) / 1000.0 if (t1 is not None and t2 is not None and t2 > t1) else None
        # --- speed
        wpm = (len(typed) / 5.0) / (dur / 60.0) if dur else None
        think = (t1 - t_show) / 1000.0 if (t1 is not None and t_show is not None and t1 >= t_show) else None
        dds = [p["dd_ms"] for p in ps if p["dd_ms"] is not None and p["dd_ms"] > 0 and not p["is_enter"]]   # key-to-key gaps (down to down)
        dd_short = [x for x in dds if x < 2000]
        # --- key hold (letters only, ignore stuck keys)
        holds = [p["hold_ms"] for p in ps if p["is_char"] and p["key"].isalpha() and p["hold_ms"] is not None and 0 < p["hold_ms"] < 1000]
        # --- errors
        n = len(ps)
        nbs = sum(1 for p in ps if p["is_backspace"])
        ed = E.lev(target, typed) if target else None
        acc = (1 - ed / max(1, len(target))) if target else None
        # burst length: characters typed between corrections (a run of backspaces counts as one correction)
        bursts, run, in_bs = [], 0, False
        for p in ps:
            if p["is_backspace"]:
                if not in_bs:
                    bursts.append(run); run = 0
                in_bs = True
            elif p["is_char"]:
                run += 1; in_bs = False
        # --- drift: first half vs second half of the key presses
        h = n // 2
        a, b = ps[:h], ps[h:]
        def half_speed(x):
            g = [p["dd_ms"] for p in x if p["dd_ms"] is not None and 0 < p["dd_ms"] < 2000]
            return E.med(g)
        def half_err(x):
            return 100.0 * sum(1 for p in x if p["is_backspace"]) / len(x) if x else None
        d1, d2 = half_speed(a), half_speed(b)
        e1, e2 = half_err(a), half_err(b)
        # --- attention (during this unit only)
        lo, hi = (t_show if t_show is not None else ps[0]["down_t"]), (t2 if t2 is not None else ps[-1]["down_t"])
        blur = sum(1 for r in uis if lo <= r["t"] <= hi and r["event"] in ("window_blur", "textarea_blur"))
        hidden = sum(1 for r in uis if lo <= r["t"] <= hi and r["event"] == "visibility" and r["detail"] == "hidden")
        out.append({
            "session_id": s["session_id"], "participant_id": s["participant_id"], "session_start_local": (s.get("clock") or {}).get("start_local_iso"),
            "task": E_name(s, u["task"]), "question_id": u.get("question_id"), "question_type": u.get("question_type"),
            "kss": (s.get("self_report") or {}).get("kss"), "completed_session": s.get("completed"),
            # speed
            "wpm": E.r3(wpm), "think_time_s": E.r3(think), "mean_gap_ms": E.r3(E.mean(dd_short)), "median_gap_ms": E.r3(E.med(dd_short)),
            # rhythm variability
            "dd_iqr_ms": E.r3(E.iqr(dd_short)), "hold_iqr_ms": E.r3(E.iqr(holds)), "gap_sd_ms": E.r3(sd(dd_short)),
            # hesitation
            "pauses_1s_per_100_keys": E.r3(100.0 * sum(1 for x in dds if x >= 1000) / n),
            "pauses_2s_per_100_keys": E.r3(100.0 * sum(1 for x in dds if x >= 2000) / n),
            "longest_pause_ms": E.r3(max(dds)) if dds else None,
            "share_gaps_over_500ms": E.r3(sum(1 for x in dds if x > LONG_GAP_MS) / len(dds)) if dds else None,
            # errors
            "backspace_per_100_keys": E.r3(100.0 * nbs / n), "accuracy": E.r3(acc), "exact_match": int(typed == target) if target else None,
            "mean_burst_before_correction": E.r3(E.mean(bursts)) if bursts else None, "n_corrections": len(bursts),
            # key hold
            "hold_med_ms": E.r3(E.med(holds)), "hold_var_ms2": E.r3(var(holds)),
            # attention
            "n_blur_events": blur, "n_hidden_events": hidden,
            # drift (second half minus first half; positive gap change = slowing down)
            "gap_med_first_half_ms": E.r3(d1), "gap_med_second_half_ms": E.r3(d2),
            "gap_change_ms": E.r3(d2 - d1) if (d1 is not None and d2 is not None) else None,
            "backspace_rate_first_half": E.r3(e1), "backspace_rate_second_half": E.r3(e2),
            "backspace_change": E.r3(e2 - e1) if (e1 is not None and e2 is not None) else None,
            "n_key_presses": n,
        })
    return out


def E_name(s, idx):
    return next((t["name"] for t in s.get("tasks", []) if t["idx"] == idx), None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inputs", action="append", default=[])
    ap.add_argument("--out", default="out")
    ap.add_argument("--kind", default="transform", choices=["transform", "free"])
    ap.add_argument("--include-test", action="store_true")
    a = ap.parse_args()
    sessions, _, _ = E.load_sessions(a.inputs or [str(HERE / "data" / "sessions")])
    rows = []
    for s, _src in sessions:
        if s.get("test_mode") and not a.include_test:
            continue
        rows += features_for(s, a.kind)
    if not rows:
        raise SystemExit("No sessions with typing data found.")
    Path(a.out).mkdir(parents=True, exist_ok=True)
    p = Path(a.out) / "features.csv"
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    print(f"Wrote {len(rows)} row(s) to {p.resolve()}")
    for r in rows:
        print()
        for k, v in r.items():
            print(f"  {k:32s} {v}")


if __name__ == "__main__":
    main()
