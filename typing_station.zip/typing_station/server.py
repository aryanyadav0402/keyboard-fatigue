#!/usr/bin/env python3
"""Typing Station collector (Python 3.8+, standard library only).

    python server.py                       # serves the app + saves sessions under ./data
    python server.py --port 8000 --mirror "D:/backup"   # also write every file to a second folder

What it does
  * Serves index.html at /, so a laptop can run the app and the collector together.
  * POST /api/session     final session JSON  -> data/sessions/<PARTICIPANT>/<session_id>.json
  * POST /api/checkpoint  partial JSON        -> data/partial/<PARTICIPANT>/<session_id>.json (overwritten)
  * Every write is atomic (temp file + fsync + rename), so a crash can never leave a half-written file.
  * Appends one line per received file to data/ledger.jsonl (time, sizes, sha256, client clock skew).
  * The exact bytes the browser sent are stored (no re-serialising), so nothing is altered.
  * Sending the same final session twice is harmless (same sha256 -> "duplicate").

Network note: the server listens on all interfaces so teammates on the same network can reach it.
Anyone on that network could post data to it, so use a private hotspot/Wi-Fi, not a public one.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import socket
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

VERSION = "1.0.0"
HERE = Path(__file__).resolve().parent
MAX_BODY = 40 * 1024 * 1024
SID_RE = re.compile(r"^[0-9A-Fa-f-]{8,64}$")
PID_BAD = re.compile(r"[^A-Za-z0-9_-]")

LOCK = threading.Lock()
CONF = {"data": None, "mirrors": []}


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def atomic_write(path: Path, data: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=".part")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    try:  # make the rename itself durable (not possible on Windows)
        dfd = os.open(str(path.parent), os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except OSError:
        pass


def append_line(path: Path, line: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(line + "\n")
        f.flush()
        os.fsync(f.fileno())


def store(kind: str, pid: str, sid: str, body: bytes):
    """Write body for (kind, pid, sid). Returns (relative_path, duplicate, sha256)."""
    sha = hashlib.sha256(body).hexdigest()
    sub = "sessions" if kind == "final" else "partial"
    rel = Path(sub) / pid / f"{sid}.json"
    primary = CONF["data"] / rel
    duplicate = False
    if kind == "final" and primary.exists():
        existing = hashlib.sha256(primary.read_bytes()).hexdigest()
        if existing == sha:
            duplicate = True
        else:  # same session id, different content: never overwrite a final file
            rel = Path(sub) / pid / f"{sid}__{sha[:8]}.json"
            primary = CONF["data"] / rel
            log(f"WARNING: session {sid} already stored with different content; kept both ({rel.name})")
    if not duplicate:
        atomic_write(primary, body)
        for m in CONF["mirrors"]:
            try:
                atomic_write(m / rel, body)
            except Exception as e:  # mirror problems must be loud but never fatal
                log(f"WARNING: mirror write failed for {m}: {e}")
    return str(rel).replace("\\", "/"), duplicate, sha


def count_sessions():
    d = CONF["data"] / "sessions"
    return sum(1 for _ in d.rglob("*.json")) if d.exists() else 0


class Handler(BaseHTTPRequestHandler):
    server_version = "TypingStation/" + VERSION
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # quieter default logging
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Client-Epoch-Ms")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")

    def _send(self, code, payload: bytes, ctype="application/json"):
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj).encode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            f = HERE / "index.html"
            if f.exists():
                return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
            return self._json(404, {"ok": False, "error": "index.html not found next to server.py"})
        if path == "/api/ping":
            return self._json(200, {"ok": True, "version": VERSION, "server_epoch_ms": int(time.time() * 1000)})
        if path == "/api/status":
            with LOCK:
                n = count_sessions()
            return self._json(200, {"ok": True, "version": VERSION, "sessions_stored": n,
                                    "server_epoch_ms": int(time.time() * 1000)})
        return self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        path = self.path.split("?")[0]
        if path not in ("/api/session", "/api/checkpoint"):
            return self._json(404, {"ok": False, "error": "not found"})
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            n = 0
        if n <= 0 or n > MAX_BODY:
            return self._json(413, {"ok": False, "error": "bad body size"})
        body = self.rfile.read(n)
        if len(body) != n:
            return self._json(400, {"ok": False, "error": "short read"})
        try:
            obj = json.loads(body.decode("utf-8"))
            assert isinstance(obj, dict) and obj.get("schema") == "typing-station"
            sid = str(obj["session_id"])
            pid = PID_BAD.sub("", str(obj.get("participant_id", "")))[:32] or "UNKNOWN"
            assert SID_RE.match(sid)
        except Exception:
            return self._json(400, {"ok": False, "error": "not a typing-station session"})
        kind = "final" if path == "/api/session" else "checkpoint"
        try:
            with LOCK:
                rel, dup, sha = store(kind, pid, sid, body)
                try:
                    cms = int(self.headers.get("X-Client-Epoch-Ms", "0"))
                except ValueError:
                    cms = 0
                now_ms = int(time.time() * 1000)
                append_line(CONF["data"] / "ledger.jsonl", json.dumps({
                    "received_epoch_ms": now_ms, "received_local": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "kind": kind, "participant_id": pid, "session_id": sid, "bytes": len(body),
                    "sha256": sha, "file": rel, "duplicate": dup, "remote_addr": self.client_address[0],
                    "client_epoch_ms": cms or None, "clock_skew_ms": (now_ms - cms) if cms else None,
                    "completed": obj.get("completed"), "recovered": obj.get("recovered"),
                    "test_mode": obj.get("test_mode")}))
        except Exception as e:
            log(f"ERROR saving {kind} {pid}/{sid}: {e!r}")
            return self._json(500, {"ok": False, "error": f"server could not save: {e}"})
        if kind == "final":
            log(f"saved FINAL  {pid:<10} {sid[:8]} {len(body)/1024:7.1f} KB"
                f"{' (duplicate)' if dup else ''}  completed={obj.get('completed')}")
        return self._json(200, {"ok": True, "kind": kind, "bytes": len(body), "sha256": sha,
                                "file": rel, "duplicate": dup})


def lan_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not ip.startswith("127."):
                ips.add(ip)
    except Exception:
        pass
    return sorted(ips)


def main():
    ap = argparse.ArgumentParser(description="Typing Station collector")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--data-dir", default=str(HERE / "data"))
    ap.add_argument("--mirror", action="append", default=[], help="extra folder that receives a copy of every file (repeatable)")
    a = ap.parse_args()

    CONF["data"] = Path(a.data_dir).resolve()
    CONF["mirrors"] = [Path(m).resolve() for m in a.mirror]
    CONF["data"].mkdir(parents=True, exist_ok=True)
    for m in CONF["mirrors"]:
        m.mkdir(parents=True, exist_ok=True)

    free_mb = shutil.disk_usage(str(CONF["data"])).free / 1e6
    print("=" * 64)
    print(f"Typing Station collector {VERSION}")
    print(f"  data folder : {CONF['data']}")
    for m in CONF["mirrors"]:
        print(f"  mirror      : {m}")
    print(f"  on this PC  : http://localhost:{a.port}")
    for ip in lan_ips():
        print(f"  on the LAN  : http://{ip}:{a.port}   <- teammates open this")
    print(f"  free disk   : {free_mb:,.0f} MB" + ("   (LOW!)" if free_mb < 200 else ""))
    print(f"  sessions already stored: {count_sessions()}")
    print("=" * 64)
    print("Leave this window open. Press Ctrl+C to stop.\n", flush=True)

    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    srv.daemon_threads = True
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped.")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
