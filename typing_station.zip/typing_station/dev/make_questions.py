#!/usr/bin/env python3
"""Build and check the question pool used by Task 1 (the rotating transformation questions).

    python dev/make_questions.py --check          # verify rules, balance, uniqueness; print stats
    python dev/make_questions.py --write          # also rewrite the QUESTIONS block inside index.html

The expected answer of every question is COMPUTED from its rule, never typed by hand, so it cannot drift.
Items 1-10 are the ones supplied by the team (their hand-written expected answers are compared below);
items 11-30 were added so every type has 6 items (a participant sees no repeat for 30 sessions).
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VOWELS = set("aeiou")

# type -> (small instruction shown above the sentence, transform function)
def cap_vowels(s):
    return "".join(c.upper() if c in VOWELS else c for c in s)


def first_last(s):
    out = []
    for w in s.split(" "):
        out.append(w[0].upper() + w[1:-1] + w[-1].upper() if len(w) > 1 else w.upper())
    return " ".join(out)


TYPES = {
    "capitalize_vowels": ("Type this sentence, but CAPITALIZE all vowels (a, e, i, o, u):", cap_vowels),
    "dashes_for_spaces": ("Replace every space with a dash (-):", lambda s: s.replace(" ", "-")),
    "dots_and_vowels": ("Replace every space with a dot (.) and CAPITALIZE all vowels:", lambda s: cap_vowels(s).replace(" ", ".")),
    "dashes_and_vowels": ("Replace spaces with dashes (-) and CAPITALIZE all vowels:", lambda s: cap_vowels(s).replace(" ", "-")),
    "capitalize_first_and_last": ("Capitalize the FIRST and LAST letter of each word:", first_last),
}
TYPE_ORDER = list(TYPES)

# (id, type, source sentence, hand-written expected from the team or None)
ITEMS = [
    (1, "capitalize_vowels", "the calico cat gave a pretty flower to the angry cow", "thE cAlIcO cAt gAvE A prEtty flOwEr tO thE Angry cOw"),
    (2, "dashes_for_spaces", "a sleepy panda shared a sweet red apple with a tiny duck", "a-sleepy-panda-shared-a-sweet-red-apple-with-a-tiny-duck"),
    (3, "capitalize_vowels", "three fluffy bunnies baked a giant blueberry pie", "thrEE flUffy bUnnIEs bAkEd A gIAnt blUEbErry pIE"),
    (4, "dots_and_vowels", "the baby otter floated down the calm blue river", "thE.bAby.OttEr.flOAtEd.dOwn.thE.cAlm.blUE.rIvEr"),
    (5, "capitalize_vowels", "a cheerful Shiba Inu wore a tiny yellow raincoat", "A chEErfUl ShIbA InU wOrE A tIny yEllOw rAIncOAt"),
    (6, "dashes_and_vowels", "the polite pig invited the hedgehog to tea", "thE-pOlItE-pIg-InvItEd-thE-hEdgEhOg-tO-tEA"),
    (7, "capitalize_vowels", "a curious raccoon found a shiny golden key", "A cUrIOUs rAccOOn fOUnd A shIny gOldEn kEy"),
    (8, "capitalize_first_and_last", "the clumsy bear dropped his favorite jar of honey", "ThE ClumsY BeaR DroppeD HiS FavoritE JaR O F HoneY"),
    (9, "capitalize_vowels", "the grumpy owl read a bedtime story to a tiny mouse", "thE grUmpy Owl rEAd A bEdtImE stOry tO A tIny mOUsE"),
    (10, "dots_and_vowels", "a happy little capybara took a warm bath", "A.hAppy.lIttlE.cApybArA.tOOk.A.wArm.bAth"),
    # ---- added to reach 6 per type ----
    (11, "capitalize_vowels", "the hungry caterpillar munched through seven green leaves", None),
    (12, "dashes_for_spaces", "a gentle giraffe nibbled leaves from the tallest tree", None),
    (13, "dashes_for_spaces", "the quiet rabbit hid behind a mossy wooden gate", None),
    (14, "dashes_for_spaces", "the cheerful chef baked fresh bread for the village", None),
    (15, "dashes_for_spaces", "a brave little mouse carried cheese across the kitchen", None),
    (16, "dashes_for_spaces", "the tired farmer fed the hungry goats at sunset", None),
    (17, "dots_and_vowels", "the shy penguin slid across the frozen pond", None),
    (18, "dots_and_vowels", "the sleepy kitten curled up beside the warm fire", None),
    (19, "dots_and_vowels", "two playful puppies chased the bouncing orange ball", None),
    (20, "dots_and_vowels", "a wise tortoise told stories to the village children", None),
    (21, "dashes_and_vowels", "the lazy sloth napped under a purple umbrella", None),
    (22, "dashes_and_vowels", "a clever fox borrowed a map from the old owl", None),
    (23, "dashes_and_vowels", "the friendly dolphin splashed the excited children", None),
    (24, "dashes_and_vowels", "a cheerful robin sang a song at the window", None),
    (25, "dashes_and_vowels", "the kind farmer gave a warm blanket to the lamb", None),
    (26, "capitalize_first_and_last", "the tiny hamster stored seeds inside his cozy wheel", None),
    (27, "capitalize_first_and_last", "the proud peacock spread his shimmering blue feathers", None),
    (28, "capitalize_first_and_last", "the gentle whale hummed slow songs to the moon", None),
    (29, "capitalize_first_and_last", "the sleepy koala hugged his branch in the old tree", None),
    (30, "capitalize_first_and_last", "the brave knight rescued two small dragons from rain", None),
]


def build():
    out = []
    for qid, typ, src, _ in ITEMS:
        instr, fn = TYPES[typ]
        out.append({"id": qid, "type": typ, "instruction": instr, "source": src,
                    "prompt": f"{instr} '{src}'", "expected": fn(src)})
    return out


def check(pool):
    ok = True
    ids = [q["id"] for q in pool]
    if len(set(ids)) != len(ids):
        print("FAIL duplicate ids"); ok = False
    if len({q["source"] for q in pool}) != len(pool):
        print("FAIL duplicate sentences"); ok = False
    print("per type:", {t: sum(1 for q in pool if q["type"] == t) for t in TYPE_ORDER})
    for (qid, typ, src, hand), q in zip(ITEMS, pool):
        if hand is not None and hand != q["expected"]:
            print(f"NOTE  item {qid}: hand-written expected differs from the rule\n        hand : {hand!r}\n        rule : {q['expected']!r}")
    for q in pool:
        if not re.fullmatch(r"[A-Za-z .\-]+", q["expected"]):
            print("FAIL unexpected characters in", q["id"]); ok = False
        if q["type"] == "capitalize_first_and_last" and any(len(w) < 2 for w in q["source"].split()):
            print("FAIL one-letter word in first/last item", q["id"]); ok = False
    L = [len(q["source"]) for q in pool]
    W = [len(q["source"].split()) for q in pool]
    V = [sum(c in VOWELS for c in q["source"]) for q in pool]
    print(f"sentence length chars: min {min(L)} max {max(L)} mean {sum(L)/len(L):.1f}; words: {min(W)}-{max(W)}; vowels: {min(V)}-{max(V)}")
    user = [q for q in pool if q["id"] <= 10]
    print(f"team's items (1-10) mean length {sum(len(q['source']) for q in user)/10:.1f}; added items (11-30) mean {sum(len(q['source']) for q in pool if q['id'] > 10)/20:.1f}")
    return ok


def write(pool):
    p = ROOT / "index.html"
    s = p.read_text(encoding="utf-8")
    block = "/*QUESTIONS_START*/" + json.dumps(pool, ensure_ascii=False, indent=1) + "/*QUESTIONS_END*/"
    s2, n = re.subn(r"/\*QUESTIONS_START\*/.*?/\*QUESTIONS_END\*/", lambda m: block, s, flags=re.S)
    if n != 1:
        sys.exit("markers not found in index.html")
    p.write_text(s2, encoding="utf-8")
    print("index.html updated with", len(pool), "questions")


if __name__ == "__main__":
    pool = build()
    good = check(pool)
    if "--write" in sys.argv:
        if not good:
            sys.exit("not writing: checks failed")
        write(pool)
    sys.exit(0 if good else 1)
