#!/usr/bin/env python3
"""End-to-end self-test for Typing Station using a real headless Chromium (optional dev tool).

    pip install playwright && playwright install chromium
    python dev/selftest.py <scratch_dir>

Runs the app in ?test=1 mode (short timers) and checks:
  A  full session + returning-participant session, saved to the collector, file copy identical, export numbers right
  B  collector goes down at finish -> session waits in the outbox -> arrives automatically after the collector returns
  C  page reload mid-session -> recovered as an incomplete session
  D  "Stop & save" produces an incomplete but saved session
"""
import csv
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
SCRATCH = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path("selftest_scratch").resolve()
DATA = SCRATCH / "data"
OUT = SCRATCH / "out"
DL = SCRATCH / "downloads"
for p in (SCRATCH, DL):
    p.mkdir(parents=True, exist_ok=True)

FREE = "I left home early, caught the bus into town and then walked up the hill to the venue with a coffee in my hand. "
FAILS = []


def snap(page, tag):
    """On failure: screenshot + what the app thinks its state is."""
    try:
        page.screenshot(path=str(SCRATCH / f"fail_{tag}.png"))
        info = page.evaluate("(()=>{const S=window.__ts.session(); return S?{status:S.status,tasks:S.tasks,err:S.error,ui:S.ui.slice(-14),pvt_rows:S.pvt.length,"
                             "pvt_running:window.__ts.pvtRunning(),pvt_state:window.__ts.pvtState(),rec:window.__ts.recActive()}:null})()")
        print("SNAP", tag, json.dumps(info)[:2500], flush=True)
        print("TEXT", page.inner_text("main")[:400].replace("\n", " | "), flush=True)
    except Exception as e:
        print("snap failed", e, flush=True)


def check(cond, msg):
    print(("  ok   " if cond else "  FAIL ") + msg, flush=True)
    if not cond:
        FAILS.append(msg)


def start_server(port):
    p = subprocess.Popen([sys.executable, str(ROOT / "server.py"), "--port", str(port), "--data-dir", str(DATA)],
                         stdout=open(SCRATCH / f"server_{port}.log", "a"), stderr=subprocess.STDOUT)
    for _ in range(50):
        try:
            urllib.request.urlopen(f"http://localhost:{port}/api/ping", timeout=1).read()
            return p
        except Exception:
            time.sleep(0.1)
    raise RuntimeError("server did not start")


def stop(p):
    p.send_signal(signal.SIGINT)
    try:
        p.wait(5)
    except Exception:
        p.kill()


def session_files():
    return sorted((DATA / "sessions").rglob("*.json")) if (DATA / "sessions").exists() else []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fill_self_report(page, kss=4, profile=True):
    page.check(f'input[name=kss][value="{kss}"]')
    page.check('input[name=mental_fatigue][value="3"]')
    page.check('input[name=motivation][value="4"]')
    page.fill("#sleep_last_night_h", "6.5")
    page.check('input[name=caffeine_last3h][value="1"]')
    page.click("#sr #go")


def drive_pvt(page, delays, early_press=False):
    page.wait_for_function("window.__ts.pvtRunning()", timeout=5000)
    i, early_done = 0, False
    t_end = time.time() + 60
    while time.time() < t_end:
        st = page.evaluate("[window.__ts.pvtRunning(), window.__ts.pvtState()]")
        if not st[0]:
            return
        if early_press and not early_done and st[1] == "isi":
            page.keyboard.press("Space")
            early_done = True
            continue
        if st[1] == "stim":
            page.wait_for_timeout(delays[i % len(delays)])
            i += 1
            page.keyboard.press("Space")
            page.wait_for_timeout(60)
        else:
            page.wait_for_timeout(8)
    raise RuntimeError("PVT did not finish")


def run_session(page, pid, cohort="teammate", typo=True, stop_after=None, pvt_delays=(230, 280, 330, 450), early=True):
    """Drive a session. stop_after in {None,'q1'}. Returns after the end screen (or at stop point)."""
    page.fill("#pid", pid)
    page.select_option("#cohort", cohort)
    page.click("#go")
    page.wait_for_selector("#sr")
    fill_self_report(page)
    page.wait_for_selector("text=Task 1", timeout=10000)
    page.click("#go")
    for i, q in enumerate(page.evaluate("window.__ts.session().config.questions")):
        s = q["expected"]
        page.wait_for_selector("#ta")
        page.wait_for_function(f"document.querySelector('#target') && document.querySelector('#target').textContent === {json.dumps(q['source'])}")
        if typo and i == 0:
            page.keyboard.type(s[:15], delay=45)
            page.keyboard.type("zz", delay=45)
            page.keyboard.press("Backspace")
            page.keyboard.press("Backspace")
            page.keyboard.type(s[15:], delay=45)
        else:
            page.keyboard.type(s, delay=45)
        page.keyboard.press("Enter")
        if stop_after == "q1" and i == 0:
            page.wait_for_timeout(1500)
            return
    page.wait_for_selector("text=Task 2 · Reaction test (20 seconds)")
    check(page.locator("text=practice").count() == 0, "S1 no practice round is mentioned")
    page.click("#go")
    drive_pvt(page, pvt_delays, early_press=early)
    try:
        page.wait_for_selector("input[name=interrupted]", timeout=10000)
    except Exception:
        snap(page, "post_screen")
        raise
    page.check('input[name=interrupted][value="little"]')
    page.fill("#notes", "selftest")
    page.click("#pf #go")
    page.wait_for_selector("#st-file .txt")
    page.wait_for_function("!document.querySelector('#st-server .txt').textContent.includes('Sending')", timeout=15000)


def read_csv(name):
    with open(OUT / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


with sync_playwright() as pw:
    browser = pw.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1000, "height": 900}, accept_downloads=True)
    page = ctx.new_page()
    errs, downloads = [], []
    page.on("pageerror", lambda e: errs.append(str(e)))
    page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    page.on("download", lambda d: downloads.append(d))
    page.on("dialog", lambda d: d.accept())

    # ------------------------------------------------------------------ A
    print("\n== A: full session, returning session, export ==", flush=True)
    srv = start_server(8791)
    page.goto("http://localhost:8791/?test=1")
    page.wait_for_selector("#pid")
    run_session(page, "T01")
    check("Received by collector" in page.inner_text("#st-server"), "A1 collector confirmed receipt: " + page.inner_text("#st-server"))
    check("Saved in this browser" in page.inner_text("#st-local"), "A2 saved in browser storage")
    check("downloaded" in page.inner_text("#st-file"), "A3 file copy downloaded")
    files = session_files()
    check(len(files) == 1, f"A4 one session file on disk ({len(files)})")
    raw = json.loads(files[0].read_text())
    check(raw["completed"] is True and raw["participant_id"] == "T01", "A5 session completed flag and id")
    check(raw["config"]["practice_pvt"] is False and raw["config"]["free_task"] is False, "A6 no practice PVT and no free-text task configured")
    check([t["name"] for t in raw["tasks"]] == ["transform_typing", "pvt_main"] and not [u for u in raw["units"] if u["kind"] == "free"]
          and not [r for r in raw["pvt"] if r[0] == "practice"], "A6b only Task 1 then the main reaction test were recorded")
    check(raw["config"]["durations_s"]["pvt_main_s"] == 20, "A6c reaction test lasts 20 s")
    units = raw["units"]
    qs = raw["config"]["questions"]
    tu = [u for u in units if u["kind"] == "transform"]
    check([u["typed"] for u in tu] == [q["expected"] for q in qs] and len(tu) == 1, "A7 typed answer equals the expected answer (typo was corrected)")
    check(all(k in tu[0] for k in ("question_id", "question_type", "instruction", "source", "prompt", "expected", "typed"))
          and tu[0]["question_id"] == qs[0]["id"] and tu[0]["prompt"] == qs[0]["prompt"], "A7b question id/type/prompt/expected/typed all saved in the unit")
    check(raw["config"]["question_pool_id"] == "transform-v1" and raw["config"]["question_pool_size"] == 30, "A7c pool id and size recorded in config")
    main = [dict(zip(raw["pvt_fields"], r)) for r in raw["pvt"] if r[0] == "main"]
    outcomes = [r["outcome"] for r in main]
    check(len(main) >= 3, f"A8 main PVT rows recorded: {outcomes}")
    check("lapse" in outcomes, "A9 a 450 ms response was classified as a lapse")
    check("false_start" in outcomes, "A10 early press recorded as false start")
    rts = [r["rt_ms"] for r in main if r["rt_ms"] is not None and r["outcome"] in ("valid", "lapse")]
    check(all(150 < x < 900 for x in rts), f"A11 RTs plausible given 230-450 ms injected delays: {[round(x) for x in rts]}")
    kd = sum(1 for k in raw["keys"] if k[2] == "d")
    ku = sum(1 for k in raw["keys"] if k[2] == "u")
    check(kd > 40 and abs(kd - ku) <= 3, f"A12 key downs {kd} ups {ku}")
    check(any(i[3] == "deleteContentBackward" for i in raw["inputs"]), "A13 backspace input events recorded")
    check(len(downloads) >= 1, "A14 a file copy was downloaded")
    dl_path = DL / "A_copy.json"
    downloads[-1].save_as(str(dl_path))
    check(sha(dl_path) == sha(files[0]), "A15 downloaded file is byte-identical to the collector's file")
    ledger = [json.loads(l) for l in (DATA / "ledger.jsonl").read_text().splitlines()]
    check(any(l["kind"] == "final" and l["sha256"] == sha(files[0]) for l in ledger), "A16 ledger has the final entry with matching sha256")
    check(any(l["kind"] == "checkpoint" for l in ledger), "A17 checkpoints were also sent during the session")
    page.screenshot(path=str(SCRATCH / "end_screen.png"))

    # returning participant
    page.click("#again")
    run_session(page, "T01", early=False)
    check("Received by collector" in page.inner_text("#st-server"), "A18 second session received")
    files = session_files()
    check(len(files) == 2, f"A19 two sessions on disk ({len(files)})")
    second = json.loads([f for f in files if json.loads(f.read_text())["local_session_number"] == 2][0].read_text())
    check(second["profile"] is None and set(second["self_report"]) == {"kss", "mental_fatigue", "motivation", "sleep_last_night_h", "caffeine_last3h", "answered_epoch_ms", "answered_t"},
          f"A20 only the 5 short questions were asked: {sorted(second['self_report'])}")
    check(second["consent"].get("waived") is True and raw["consent"].get("waived") is True and raw["participant_name"] == "T01",
          "A21 no consent screen (waived recorded) and the typed name is saved as participant_name")
    nm = page.evaluate("['Ananya G', ' zoë  O\\'Neil ', 'T01', 'w-b001', '', '***'].map(window.__ts.normPid)")
    check(nm == ["ANANYA-G", "ZOE-ONEIL", "T01", "W-B001", "", ""], f"A21h names become stable ids: {nm}")
    check(second["completed"] is True, "A21b returning session (no practice task) is marked completed")
    check(second["config"]["questions"][0]["id"] != raw["config"]["questions"][0]["id"]
          and second["config"]["questions"][0]["type"] != raw["config"]["questions"][0]["type"], "A21c returning participant gets a different question (and a different rule type)")
    ids = page.evaluate("Array.from({length:30},(_,n)=>window.__ts.pickQuestions('T01',n)[0].id)")
    types = page.evaluate("Array.from({length:30},(_,n)=>window.__ts.pickQuestions('T01',n)[0].type)")
    check(len(set(ids)) == 30, "A21d no repeated question over 30 visits for one participant")
    check(all(len(set(types[i:i + 5])) == 5 for i in range(0, 30, 5)), "A21e every block of 5 visits covers all 5 rule types")
    starts = page.evaluate("['T01','T02','T03','T04','W-AB12','W-QZ77'].map(p=>window.__ts.pickQuestions(p,0)[0].type)")
    check(len(set(starts)) >= 3, f"A21f different participants start on different rule types: {starts}")
    check(page.evaluate("window.__ts.pickQuestions('T01',0).length") == 1, "A21g one question per session")

    subprocess.run([sys.executable, str(ROOT / "export.py"), "--in", str(DATA / "sessions"), "--out", str(OUT), "--include-test"],
                   check=True, stdout=open(SCRATCH / "export.log", "w"))
    S = read_csv("sessions.csv")
    check(len(S) == 2 and [r["session_index"] for r in S] == ["1", "2"], "A22 export: 2 sessions with session_index 1,2")
    r1 = S[0]
    check(r1["kss"] == "4" and r1["motivation"] == "4" and r1["mental_fatigue"] == "3", "A23 export: self-report values")
    check(S[0]["participant_name"] == "T01", "A24 export: participant_name column")
    check(r1["transform_accuracy"] == "1.0" and r1["transform_exact_match_rate"] == "1.0" and float(r1["transform_wpm"]) > 20,
          f"A25 export: transform accuracy {r1['transform_accuracy']}, exact {r1['transform_exact_match_rate']}, wpm {r1['transform_wpm']}")
    check(float(r1["transform_backspace_per_100_keys"]) > 0 and float(S[1]["transform_backspace_per_100_keys"]) > 0, "A26 export: backspace rate present (typo session > 0)")
    check(r1["transform_question_ids"] == str(raw["config"]["questions"][0]["id"]) and r1["transform_question_types"] == raw["config"]["questions"][0]["type"],
          "A26b export: question id and type in sessions.csv")
    check(r1["transform_think_time_s"] not in ("", None) and float(r1["transform_think_time_s"]) >= 0, f"A26c export: think time {r1['transform_think_time_s']} s")
    U = read_csv("typing_units.csv")
    ut = [r for r in U if r["kind"] == "transform"][0]
    check(ut["question_id"] == str(qs[0]["id"]) and ut["instruction"] == qs[0]["instruction"] and ut["expected"] == qs[0]["expected"] and ut["typed"] == qs[0]["expected"]
          and ut["exact_match"] == "1", "A26d export: typing_units.csv has question id, instruction, expected, typed, exact_match")
    check(int(r1["pvt_lapses_355"]) >= 1 and int(r1["pvt_n_false_starts"]) >= 1, "A27 export: PVT lapse and false-start counts")
    check(r1["sleep_last_night_h"] == "6.5" and r1["caffeine_last3h"] == "1" and 0 <= float(r1["local_hour"]) < 24, "A28 export: sleep, caffeine and local_hour present")
    check("TEST_MODE" in r1["qc_flags"], "A29 export: test-mode flag present")
    check("no_free_text" not in r1["qc_flags"] and "free_few_keys" not in r1["qc_flags"] and r1["free_n_presses"] in ("", "0"), f"A29b export: no free-text flags/columns filled ({r1['qc_flags']})")
    T = read_csv("keystroke_timings.csv")
    dds = sorted(float(r["dd_ms"]) for r in T if r["dd_ms"] and r["task_name"] == "transform_typing")
    check(40 < dds[len(dds) // 2] < 140, f"A30 export: median down-down {dds[len(dds)//2]:.0f} ms for 45 ms injected delay")
    check(len(read_csv("keystrokes.csv")) == sum(len(json.loads(f.read_text())["keys"]) for f in files), "A31 export: keystrokes.csv rows == raw events")
    P = read_csv("pvt_trials.csv")
    check(len(P) == sum(len(json.loads(f.read_text())["pvt"]) for f in files), "A32 export: pvt_trials.csv rows == raw trials")
    page.click("#again")

    # ------------------------------------------------------------------ B
    print("\n== B: collector down at finish, outbox, recovery (page opened from file://, like a teammate's offline copy) ==", flush=True)
    stop(srv)
    srv = start_server(8792)
    page.add_init_script("try{ if(!localStorage.getItem('ts_cfg')) localStorage.setItem('ts_cfg', JSON.stringify({server:'http://localhost:8792', station_id:'ST-TEST'})); }catch(e){}")
    page.goto("file://" + str(ROOT / "index.html") + "?test=1")
    page.wait_for_selector("#pid")
    page.wait_for_timeout(1500)
    check("Collector connected" in page.inner_text("#pill-collector"), "B0 page opened from a file reaches the collector (CORS works): " + page.inner_text("#pill-collector"))
    n_before = len(session_files())
    # run a session by hand up to the last question, then kill the collector before "Finish and save"
    page.fill("#pid", "W-B001"); page.select_option("#cohort", "walkup")
    page.click("#go")
    page.wait_for_selector("#sr"); fill_self_report(page, kss=7)
    page.wait_for_selector("text=Task 1"); page.click("#go")
    for q in page.evaluate("window.__ts.session().config.questions"):
        page.wait_for_function(f"document.querySelector('#target') && document.querySelector('#target').textContent === {json.dumps(q['source'])}")
        page.keyboard.type(q["expected"], delay=30); page.keyboard.press("Enter")
    page.wait_for_selector("text=Task 2"); page.click("#go")
    drive_pvt(page, (250, 300))
    page.wait_for_selector("input[name=interrupted]")
    check((DATA / "partial" / "W-B001").exists(), "B0b checkpoints from the file:// page reached the collector during the session")
    stop(srv)  # collector dies right before the participant presses Finish
    downloads.clear()
    page.check('input[name=interrupted][value="none"]'); page.click("#pf #go")
    page.wait_for_function("!document.querySelector('#st-server .txt').textContent.includes('Sending')", timeout=20000)
    txt = page.inner_text("#st-server")
    check("Not confirmed" in txt, "B1 participant is told the collector did not confirm: " + txt[:70])
    check("downloaded" in page.inner_text("#st-file") and len(downloads) == 1, "B2 file copy still downloaded")
    check("Saved in this browser" in page.inner_text("#st-local"), "B3 still saved in browser storage")
    check(len(session_files()) == n_before, "B4 nothing reached the collector yet")
    page.reload(); page.wait_for_selector("#pid"); page.wait_for_timeout(1500)
    check("1 unsent" in page.inner_text("#pill-unsent"), "B5 after reload the pill shows the unsent session: " + page.inner_text("#pill-unsent"))
    srv = start_server(8792)
    t_end = time.time() + 45
    while time.time() < t_end and len(session_files()) == n_before:
        time.sleep(1)
    check(len(session_files()) == n_before + 1, "B6 outbox delivered the session automatically after the collector came back")
    page.wait_for_timeout(1500)
    check("0 unsent" in page.inner_text("#pill-unsent"), "B7 pill back to 0 unsent")
    bfile = [f for f in session_files() if "W-B001" in str(f)][0]
    check(sha(bfile) == sha(downloads[0].path()) if downloads else False, "B8 delivered file identical to the downloaded copy")

    # ------------------------------------------------------------------ C
    print("\n== C: reload mid-session -> recovered ==", flush=True)
    n_before = len(session_files())
    run_session(page, "T03", stop_after="q1")
    page.wait_for_timeout(6000)   # let the 5 s autosave happen
    page.reload(); page.wait_for_selector("#pid")
    t_end = time.time() + 60
    while time.time() < t_end and len(session_files()) == n_before:
        time.sleep(1)
    check(len(session_files()) == n_before + 1, "C1 interrupted session recovered and delivered")
    cf = [f for f in session_files() if "T03" in str(f)]
    if cf:
        cr = json.loads(cf[0].read_text())
        check(cr["recovered"] is True and cr["completed"] is False and len(cr["keys"]) > 60, f"C2 recovered flag, incomplete, {len(cr['keys'])} key events kept")
        check(cr["units"] and cr["units"][0]["typed"] == cr["units"][0]["expected"], "C3 the answer typed before the crash is intact")

    # ------------------------------------------------------------------ D
    print("\n== D: stop & save ==", flush=True)
    n_before = len(session_files())
    run_session(page, "T04", stop_after="q1")
    page.click("#abort")
    page.wait_for_selector("#st-local .txt")
    page.wait_for_function("!document.querySelector('#st-server .txt').textContent.includes('Sending')", timeout=15000)
    check("Saved (incomplete session)" in page.inner_text("h2"), "D1 end screen says incomplete")
    check(len(session_files()) == n_before + 1, "D2 aborted session reached the collector")
    df = [f for f in session_files() if "T04" in str(f)]
    if df:
        dr = json.loads(df[0].read_text())
        check(dr["aborted"] is True and dr["completed"] is False, "D3 aborted flag set, not complete")
    page.wait_for_timeout(2000)
    check(page.locator("#go").count() == 0 and page.locator("#again").count() == 1, "D4 stale timers did not redraw over the end screen")

    # final export of everything
    subprocess.run([sys.executable, str(ROOT / "export.py"), "--in", str(DATA / "sessions"), "--out", str(OUT), "--include-test"],
                   check=True, stdout=open(SCRATCH / "export2.log", "w"))
    S = read_csv("sessions.csv")
    flags = {r["participant_id"]: r["qc_flags"] for r in S}
    check("recovered_after_crash" in flags.get("T03", ""), f"E1 export flags recovered session: {flags.get('T03')}")
    check("aborted" in flags.get("T04", ""), f"E2 export flags aborted session: {flags.get('T04')}")
    check(len(S) == 5, f"E3 five sessions exported ({len(S)})")

    check(not [e for e in errs if "Failed to load resource" not in e and "ERR_CONNECTION_REFUSED" not in e and "Failed to fetch" not in e],
          f"F1 no unexpected page errors: {[e for e in errs][:5]}")
    stop(srv)
    browser.close()

print("\nRESULT:", "ALL PASSED" if not FAILS else f"{len(FAILS)} FAILED")
for f in FAILS:
    print("  -", f)
sys.exit(1 if FAILS else 0)
