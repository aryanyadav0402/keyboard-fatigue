# Typing Station

A small web app for collecting **typing + reaction-time + self-reported tiredness** data from many people, with careful saving. No installs for participants, no background logging, works offline.

Each session (~3 minutes) records:
1. **Name** (typed on the first screen; used as the person's ID, so use the same name every time)
2. **Five quick questions**: sleepiness (Karolinska 1–9), mental fatigue, motivation, hours slept last night, caffeine in the last 3 hours
3. **Task 1 – change one sentence by a rule and type it** (e.g. "CAPITALIZE all vowels" or "replace every space with a dash"). The sentence and rule are different every visit, so nobody can learn them in advance
4. **Task 2 – 20-second reaction test** (press Space when the red counter appears; no practice round)
5. **One last question** (were you interrupted?)

The reaction test is the objective label, the 1–9 rating is the subjective label, and both are stored next to the raw keystroke timing.

## Start (2 minutes)

You need Python 3.8+ (nothing to install). Put this folder on the laptop that will store the data, then:

```
python server.py
```

It prints addresses like `http://localhost:8000` and `http://192.168.x.x:8000`. Open one in Chrome, Edge or Firefox.

Everyone uses **your laptop** (`localhost`), so everyone types on the same keyboard, which keeps the comparison between people clean.

(If you ever want someone to use their own laptop: they can open the `192.168.x.x` address on the same Wi-Fi, or double-click a copy of `index.html`, which works offline, downloads a `tsession_*.json` after every session and can be merged later with `export.py --in <folder>`. Their session then saves to their browser and a download only, because the collector address is no longer a setting in the page.)

## Names

* Each person types their name. It becomes their ID (accents dropped, spaces become `-`, upper-case: `Zoë O'Neil` → `ZOE-ONEIL`). The screen shows the ID it will use, and says "Welcome back" if it has seen it before.
* **Use the same spelling every time**, and make sure two people don't share a first name (use `Sam-K` and `Sam-R`). Otherwise their sessions get mixed together.
* The name is saved with every session (`participant_name`, and the folder `data/sessions/<ID>/`).
* Pick the right **Group** (teammate / walk-up). It is stored with the data. Repeat visits are far more valuable than one-offs, because tiredness is a *change within a person*.

## What to say to a walk-up

> "Can you help with a hackathon project? It takes about 3 minutes: a few quick questions, one short typing task and a 20-second reaction test. We record what keys you press and when, plus your reaction times, saved under your name. You can stop any time. Please don't type anything private."

## How data is kept safe

Every session is saved **three independent ways**, and the end screen tells the participant which worked:

| copy | where | survives |
|---|---|---|
| browser storage | IndexedDB in that browser, autosaved every 5 s while the session runs | page reload or crash (an interrupted session is recovered automatically as "incomplete") |
| collector | `data/sessions/<NAME>/<session_id>.json` on the laptop running `server.py`. Written atomically, with `data/ledger.jsonl` recording every receipt with sha256 | browser being cleared; the participant's laptop dying |
| file copy | `tsession_<NAME>_<time>_<id>.json` downloaded to the participant's Downloads | everything else going wrong |

Also:
* The collector additionally gets a **checkpoint** after every task and every minute (`data/partial/…`), so even a laptop that dies mid-session leaves the earlier parts on the collector.
* If the collector is unreachable at the end, the page says so in red, keeps the session in an **outbox**, and retries every 20 s (even after a page reload). Header pills show *Collector connected* and *N unsent*.
* **Station settings → Download backup of everything on this device** exports every session stored in that browser as one file.
* **Mirror copy**: `python server.py --mirror "D:/usb-backup"` writes every file to a second folder as well. Do this on the laptop that holds the data.
* A file copy is **always** downloaded after every session. Chrome may ask "allow this site to download multiple files?" after the first one. Click **Allow**.
* `data/` is the only thing to back up. Copy it somewhere else (USB, Drive) every few hours.

## After the event (or any time)

```
python export.py                       # reads data/sessions  ->  out/
python export.py --in data/sessions --in "C:/Users/me/Downloads" --out out
```

Merges duplicates (same session) and writes CSVs: `sessions.csv` (one row per session, with labels, the Task 1 question id/type, derived reaction-time metrics, typing summaries and QC flags), `keystroke_timings.csv` (hold/flight times per key press), `keystrokes.csv`, `pvt_trials.csv`, `typing_units.csv`, `input_events.csv`, `ui_events.csv`, and `qc_report.txt`. See **DATA_DICTIONARY.md** for every column.

Model features (speed, rhythm variability, hesitation, errors, key hold, attention, drift) can be computed from the raw files with:

```
python3 features.py                 # reads data/sessions, writes out/features.csv
```

## Protocol suggestions

* **Teammates**: check in every 60–90 min *at about the same moments*, including overnight. (There are no on-screen reminders any more; set a phone alarm.)
* **Same conditions**: same laptop and keyboard each time (everyone uses yours); try not to eat/drink/chat during the 3 minutes.
* **Order is fixed** (questions → Task 1 → reaction test) so every session has the same structure.
* **Task 1 varies on purpose** (30 questions, 6 for each of 5 rule types, no repeat for 30 visits per person, rule type cycling in turn). The rule types differ in difficulty, so compare Task 1 results within the same `question_type` or include it as a covariate. The export records the question id, type, instruction, expected answer and typed answer for every session.
* The **first session** for each person has no practice round, so their first reaction test and first typing task are partly warm-up. Treat session 1 as a warm-up in analysis.
* A **walk-up** gives one data point in time; teammates give within-person trajectories. Use walk-ups for "do typing features track reaction time across people?" and teammates for "does this person's typing drift as they get tired?".

## Privacy (please read)

* There is **no consent screen and no age check** in this version (it is meant for you and friends). Each session records `consent: waived`. Tell people verbally what is recorded (keys pressed and their timing, reaction times, their answers) and that it is saved under their **name**.
* Typing rhythm can identify a person, and the raw files now include their name and **every key pressed in the tasks**. Keep `data/` private: don't commit it to a public repo, don't post it, and delete it after the project unless people agreed otherwise.
* Anyone can ask you to delete their data: delete `data/sessions/<NAME>`, `data/partial/<NAME>` and any downloaded files.
* If you ever recruit strangers or use the data beyond the event, bring the consent screen back (the previous version, with consent, profile and the longer questionnaire, is kept as `dev/index_v1.1_with_consent_and_profile.html`) and get proper approval. This is a hackathon prototype, not legal advice.

## Changing the Task 1 questions

Edit the `ITEMS` list in `dev/make_questions.py` (id, rule type, sentence). Expected answers are computed from the rule, never typed by hand, so they cannot contain typos. Run `python dev/make_questions.py --check` (verifies rules, balance, duplicates) and then `python dev/make_questions.py --write` to put the pool into `index.html`. If you change the pool during data collection, change `QUESTION_POOL_ID` in `index.html` too. To show more than one question per visit (more keystrokes), set `QUESTIONS_PER_SESSION` in `index.html` to 2 or 3.

## Known limits (be honest about these in your write-up)

* Browser timing is good to about 1 ms for keys (0.1 ms in Chrome) but reaction times include about one screen-refresh of display delay and differ by laptop. Compare within a person and device, not raw between people. `refresh_hz_est` is recorded each session.
* The reaction test is a browser PVT-B-style implementation (3 min, random 1–4 s gaps, lapse ≥ 355 ms), not a clinical device. At 20 s it yields only about 6–9 stimuli, so lapses and slowest-10% are very noisy per session. Prefer the median or mean RT (or mean 1/RT), and average over several sessions per person.
* People differ in keyboards, typing skill and posture; session 1 has no practice round; motivation affects reaction time as well as tiredness. Self-ratings are subjective, which is why they are paired with the reaction test.
* Sessions recorded with `?test=1` have shortened timers. They are flagged `TEST_MODE` and excluded from exports unless you pass `--include-test`.

## Files

```
index.html          the app (single file, no internet needed)
server.py           collector + static server
export.py           raw JSON -> CSV tables + QC report
features.py         raw JSON -> out/features.csv (one row per session: speed, rhythm, hesitation, errors, key hold, attention and first-half/second-half drift features)
DATA_DICTIONARY.md  every column explained
dev/make_questions.py  the Task 1 question pool: add or edit questions here, then `python dev/make_questions.py --check` and `--write`
dev/selftest.py     optional end-to-end browser test (needs playwright)
dev/index_v1.1_*.html  the previous version of the app (with consent screen, profile and longer questionnaire)
```
