# Data dictionary

Raw data = one JSON file per session (`data/sessions/<PARTICIPANT>/<session_id>.json`, schema `typing-station` v1).
`python export.py` turns those into the CSV tables below. The raw JSON is the source of truth; the tables can be regenerated at any time.

## Time
* Every event time `t` / `t_ms` is milliseconds on the browser's `performance.now()` clock (since the page loaded). Differences between times are accurate; absolute times are `epoch_ms = clock.time_origin_epoch_ms + t`.
* Key events use the browser's own `event.timeStamp` (taken when the OS delivered the key), not the time our code ran. Resolution is about 0.1 ms in Chrome and 1 ms in Firefox/Safari.
* Wall-clock fields (`start_utc`, `start_local`) come from the laptop's clock. If a laptop's clock is wrong, `start_*` is wrong by the same amount (QC flag `system_clock_jump` catches clock changes mid-session).

## Task 1 questions (rotating rule + sentence)
Each visit shows one short sentence with a small rule above it (e.g. "CAPITALIZE all vowels", "replace every space with a dash"); the participant types the *changed* sentence. The pool has 30 questions (id 1–30; 1–10 supplied by the team, 11–30 added), 6 for each of 5 rule types: `capitalize_vowels`, `dashes_for_spaces`, `dots_and_vowels`, `dashes_and_vowels`, `capitalize_first_and_last`. The expected answer is computed from the rule by `dev/make_questions.py`, not typed by hand. The full pool is in `index.html`; each session's raw JSON stores the exact question(s) shown (`config.questions`) and the pool version (`config.question_pool_id`).
Rotation: for one participant the rule type cycles through all 5 types in turn (starting point depends on the participant code) and within a type the order is a fixed shuffle seeded by the code, so there is no repeat for 30 visits. Different participants start on different types.
**Analysis note:** rule types differ in difficulty (`dashes_for_spaces` is easy, `dots_and_vowels` is harder), so compare Task 1 results within the same `question_type`, or include the type as a covariate. Letter-level timings (hold, flight) are less affected than think time and accuracy.

## sessions.csv — one row per session
| column | meaning |
|---|---|
| session_id | unique id of the session (UUID) |
| participant_id | pseudonymous code (T01…, W-XXXX) |
| cohort | teammate / walkup / other |
| session_index | 1, 2, 3… for that participant, by start time, across all devices in the export |
| local_session_number | the app's own count on that device (can differ if a person used several devices) |
| collector, station_id | who/which laptop ran the station |
| start_utc, start_local, tz_offset_min | session start time (UTC, local with offset, minutes from UTC) |
| local_hour | local time of day as decimal hours (14.5 = 14:30) |
| hours_since_first_session | hours since that participant's first session |
| duration_min | start to finish |
| completed | 1 if all tasks finished and questionnaires answered |
| recovered / aborted | 1 if saved after a page crash/reload; 1 if "stop & save" was used |
| app_version, consent_version, consent_reconfirmed | protocol versions; reconfirmed = they had agreed in an earlier session |
| os_platform, browser_ua, screen_w, screen_h, dpr, refresh_hz_est | device and display (refresh rate measured at session start) |
| keyboard_type | builtin / external_wired / external_wireless / other (self-report, each session) |
| posture | desk / lap / standing / other |
| kss | Karolinska Sleepiness Scale, 1 (extremely alert) – 9 (very sleepy, fighting sleep) |
| mental_fatigue | 1 (not at all) – 5 (extremely) |
| motivation | 1 (not at all) – 5 (very) |
| wake_time | local time they woke up (HH:MM) |
| hours_awake | derived: session start minus wake_time (previous day if later than start). Naps are NOT subtracted; see nap_since_last_min |
| sleep_last_night_h | hours slept in last main sleep |
| nap_since_last_min | minutes napped since previous check-in |
| caffeine_last3h | 0 / 1 / 2 / 3+ drinks in the last 3 hours |
| caffeine_min_ago | minutes since the last caffeine (optional) |
| interrupted | none / little / lot (post-task question) |
| notes | optional free note |
| age_band, touch_typing, typing_speed_band, handedness, native_english, laptop_model | profile, asked once per participant per device, copied to all of that participant's rows |
| pvt_* | reaction-test summary (main phase only; practice excluded). See PVT section |
| transform_question_ids, transform_question_types | id(s) and rule type(s) of the Task 1 question(s) shown (see Task 1 questions) |
| free_prompt_id | which free-writing prompt was shown |
| transform_* / free_* | typing summary for Task 1 / the free-text task. See Typing section |
| n_key_events | raw key events in the typing tasks and PVT |
| n_blur_events | times the window or text box lost focus during tasks |
| n_hidden_events | times the browser tab was hidden (switched away) |
| n_paste_blocked | paste/drop attempts that were blocked |
| n_untrusted_keys | key events generated by software, not a keyboard (should be 0) |
| qc_flags | semicolon-separated flags (see below) |
| source_file | which file the export used for this session |

### PVT (reaction test) columns
Very brief (20-second, about 6–9 stimuli) psychomotor vigilance test: a red millisecond counter appears after a random 1–4 s gap; the participant presses Space. Response ≥ 355 ms = lapse (brief-PVT threshold; 500 ms count also given). A press with no stimulus, or a response < 100 ms after onset, = false start. No response in 10 s = timeout.
| column | meaning |
|---|---|
| pvt_n_main_rows | all rows in the main phase (responses + false starts + timeouts) |
| pvt_n_responses | valid + lapse responses |
| pvt_n_false_starts, pvt_n_timeouts | counts |
| pvt_lapses_355, pvt_lapses_500 | responses ≥ 355 ms / ≥ 500 ms |
| pvt_mean_rt_ms, pvt_median_rt_ms, pvt_rt_sd_ms | over valid + lapse responses |
| pvt_mean_inv_rt_per_s | mean of 1000/RT (reciprocal response speed; the most sleep-sensitive summary in the brief-PVT literature) |
| pvt_slowest10_inv_rt_per_s | mean of 1000/RT over the slowest 10% of responses |
| pvt_fastest10_rt_ms | mean RT of the fastest 10% |
| pvt_score | our implementation of a PVT performance score: 1 − (lapses + false starts) / (stimuli answered or timed out + false starts). Higher is better |

Reaction time = key event time minus the animation-frame time at which the counter first appeared. Display latency (about one screen refresh) is not subtracted, so compare within a person and device, not raw across people.

### Typing columns (prefix `transform_` or `free_`)
| column | meaning |
|---|---|
| n_presses | key presses excluding modifiers; held-key auto-repeat events are not counted |
| wpm | (typed characters / 5) / minutes from first key to Enter (Task 1) or to timer end (free). Task 1 includes thinking pauses, so it is lower than raw typing speed |
| accuracy | 1 − edit distance / length of the expected answer (Task 1 only; case-sensitive, so a missed capital counts as an error) |
| exact_match_rate | share of Task 1 answers typed exactly right |
| think_time_s | seconds from the question appearing to the first key press (thinking/reading time; a candidate fatigue signal) |
| backspace_per_100_keys | Backspace/Delete presses per 100 key presses (a held key counts once) |
| hold_med_ms, hold_iqr_ms | median / interquartile range of key hold time for letters (0 < hold < 1000 ms) |
| dd_med_ms, dd_iqr_ms | same for down-to-down time between consecutive non-modifier keys (< 2 s) |
| pauses_1s_per_100_keys, pauses_2s_per_100_keys | gaps ≥ 1 s / ≥ 2 s between key presses per 100 presses |

## keystrokes.csv — raw events (typing tasks and PVT)
| column | meaning |
|---|---|
| task, task_name | task index and name (transform_typing, free_text, pvt_practice, pvt_main) |
| unit | question number within Task 1 (0 when one question per session); 0 otherwise |
| type | d = key down, u = key up |
| t_ms, epoch_ms | event time (see Time) |
| code | physical key (layout-independent), e.g. KeyA, Space, Backspace |
| key | character or key name produced, e.g. "a", "A", " ", "Backspace" |
| shift, ctrl, alt, meta, caps_on | modifier / Caps Lock state when the event happened |
| repeat | 1 if this is OS auto-repeat from holding the key |
| composing | 1 if inside an input-method composition |
| untrusted | 1 if the event was synthetic (not from a real keyboard) |

## keystroke_timings.csv — one row per key press
Built from keystrokes.csv by matching each key down with its key up. Auto-repeat downs are dropped.
| column | meaning |
|---|---|
| order | position within the task/unit |
| code, key, prev_code | this key, and the previous non-modifier key (for digraph analysis) |
| down_t_ms, up_t_ms | press and release times |
| hold_ms | up − down (empty if no matching release was recorded) |
| dd_ms | down-to-down time from the previous non-modifier key (modifiers excluded from the chain) |
| ud_ms | previous key's release to this key's press ("flight time"); negative = the keys overlapped (rollover) |
| is_char, is_backspace, is_enter, is_modifier | key type |
| shift … untrusted | as above |

## typing_units.csv — one row per sentence / free-text block
`kind` = transform (Task 1) or free. For Task 1: `question_id`, `question_type`, `instruction` (the small rule line), `source_text` (the big sentence), `prompt` (instruction + sentence as originally written), `expected` (the correct answer, computed from the rule), `typed` (final text in the box), `edit_distance`, `accuracy`, `exact_match`. For free text: `prompt_id`, `prompt`, `typed`. Both: `t_shown_ms`, `t_first_key_ms`, `t_end_ms`, `think_time_s` (shown → first key), `duration_s`, `wpm`, `n_presses`, `n_backspace`, `n_repeat_events` (auto-repeat events dropped), `skipped`.
**Note:** the final text of the free-text block is stored, and the raw key events also reveal it. Keep this data private.

## pvt_trials.csv
`phase` (practice/main), `trial` (index), `isi_ms` (planned gap before the stimulus), `onset_t_ms` (counter appeared), `resp_t_ms` (key down), `rt_ms`, `outcome` (valid / lapse / false_start / timeout), `code`, `is_lapse_355`. Rows with outcome `false_start` and empty `onset_t_ms` are presses made when no stimulus was showing.

## input_events.csv
Text-box `input` events: `input_type` (insertText, deleteContentBackward, insertLineBreak, historyUndo, …), `text_len` (characters in the box after the event), `caret`. Pasting is blocked, so insertFromPaste should not appear.

## ui_events.csv
`event` examples: `screen` (detail = which), `task_start`/`task_end`, `window_blur`/`window_focus`, `visibility` (detail hidden/visible), `textarea_blur`, `paste_blocked`, `pvt_start`, `net_offline`, `aborted`, `error`.

## QC flags (sessions.csv → qc_flags, and qc_report.txt)
| flag | meaning |
|---|---|
| incomplete | not all tasks and questionnaires finished |
| recovered_after_crash | page reloaded/crashed; saved from the last autosave (≤ 5 s of data may be missing) |
| aborted | "Stop & save" used |
| no_self_report / no_pvt / no_transform | that part is missing (`no_free_text` appears only for sessions from app v1.0, which had a free-writing task) |
| pvt_few_responses | far fewer responses than expected for the test length |
| pvt_many_false_starts | more than 25% false starts |
| pvt_timeouts | 3 or more stimuli with no response for 10 s |
| transform_few_keys / free_few_keys (v1.0 only) | very little typing (Task 1: fewer key presses than 60% of the expected answer's length) |
| transform_low_accuracy | Task 1 accuracy under 70% (likely misunderstood the rule or did not try) |
| tab_hidden | the tab was hidden at some point (participant switched away) |
| many_blur_events | window/text box lost focus 3 or more times |
| paste_attempt | tried to paste or drop text |
| untrusted_key_events | software-generated key events were seen |
| reported_interrupted_a_lot | participant said "a lot" of interruption |
| low_refresh_rate | screen refresh under 45 Hz (power saving?) — reaction times less precise |
| system_clock_jump | laptop clock changed during the session |
| many_unmatched_keys | many key presses with no recorded release |
| js_error | the page hit an error (details in raw JSON `error`) |
| TEST_MODE | recorded with `?test=1`; excluded unless `--include-test` |

## Suggested analysis notes
* Compare people to themselves: z-score each label and feature within participant before pooling.
* `session_index` and the practice effect: the first session per person has no practice round (app v1.1+; v1.0 had a 20 s practice) and is the first exposure to the task; consider dropping or flagging session 1.
* Treat `keyboard_type` and device as nuisance factors; the walk-up cohort on one station laptop shares a keyboard, teammates each have their own.

## App version note
* v1.1.0: removed the free-writing task (all `free_*` columns and `free_prompt_id` are empty), removed the practice reaction test, and shortened the main reaction test from 180 s to 20 s. Check `app_version` and the `durations_s` in the raw JSON when mixing sessions from v1.0.
* v1.2.0: the first screen asks only for the person's name (saved as `participant_name`; `participant_id` is the normalised name, e.g. `Zoë O'Neil` → `ZOE-ONEIL`). No consent screen (`consent.waived = true`; `consent_version` says so), no profile questions, and the quick questions are only: `kss`, `mental_fatigue`, `motivation`, `sleep_last_night_h`, `caffeine_last3h`. These columns are therefore **empty** for v1.2 sessions: `wake_time`, `hours_awake`, `nap_since_last_min`, `caffeine_min_ago`, `keyboard_type`, `posture`, `age_band`, `touch_typing`, `typing_speed_band`, `handedness`, `native_english`, `laptop_model`, `consent_reconfirmed`. Time awake can still be approximated from `local_hour` and `hours_since_first_session`. A file copy is always downloaded and there are no reminders.
